"""Core primitives for the SovereignChain educational prototype."""
from __future__ import annotations
import asyncio, base64, hashlib, json, os, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, PublicFormat, NoEncryption

def canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()

def digest(obj: Any) -> str:
    return hashlib.sha256(canon(obj)).hexdigest()

def b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")

def unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"), validate=True)

def load_or_create_key(path: str) -> Ed25519PrivateKey:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        return Ed25519PrivateKey.from_private_bytes(p.read_bytes())
    key = Ed25519PrivateKey.generate()
    raw = key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    tmp = p.with_suffix(".tmp")
    tmp.write_bytes(raw)
    os.chmod(tmp, 0o600)
    tmp.replace(p)
    return key

def public_bytes(key: Ed25519PrivateKey) -> bytes:
    return key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)

def make_transaction(key: Ed25519PrivateKey, recipient: str, amount: int, nonce: int) -> dict:
    if not recipient or amount <= 0 or nonce <= 0:
        raise ValueError("recipient, positive amount, and positive nonce are required")
    body = {"sender": b64(public_bytes(key)), "recipient": recipient, "amount": amount,
            "nonce": nonce, "created_at": int(time.time())}
    return {"body": body, "signature": b64(key.sign(canon(body))), "txid": digest(body)}

def verify_transaction(tx: dict) -> bool:
    try:
        body = tx["body"]
        if tx["txid"] != digest(body) or int(body["amount"]) <= 0 or int(body["nonce"]) <= 0:
            return False
        Ed25519PublicKey.from_public_bytes(unb64(body["sender"])).verify(unb64(tx["signature"]), canon(body))
        return True
    except Exception:
        return False

@dataclass
class Node:
    name: str
    key: Ed25519PrivateKey
    peers: list[tuple[str, int]] = field(default_factory=list)
    transactions: dict[str, dict] = field(default_factory=dict)
    vertices: dict[str, dict] = field(default_factory=dict)
    last_seq: int = 0
    last_vertex: str | None = None
    seen_nonces: dict[str, int] = field(default_factory=dict)
    server: asyncio.AbstractServer | None = None

    @property
    def pub(self) -> str:
        return b64(public_bytes(self.key))

    async def start(self, host="127.0.0.1", port=0):
        self.server = await asyncio.start_server(self._handle, host, port)
        return self.server.sockets[0].getsockname()[1]

    async def close(self):
        if self.server:
            self.server.close()
            await self.server.wait_closed()

    async def _handle(self, reader, writer):
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=5)
            if not line or len(line) > 1_000_000:
                return
            msg = json.loads(line)
            typ = msg.get("type")
            if typ == "submit":
                ok, reason = await self.accept_transaction(msg["transaction"], gossip=True)
                result = {"ok": ok, "reason": reason}
            elif typ == "transaction":
                ok, reason = await self.accept_transaction(msg["transaction"], gossip=True)
                result = {"ok": ok, "reason": reason}
            elif typ == "vertex":
                ok, reason = self.accept_vertex(msg["vertex"])
                if ok:
                    await self._broadcast({"type": "vertex", "vertex": msg["vertex"]})
                result = {"ok": ok, "reason": reason}
            elif typ == "status":
                result = {"name": self.name, "public_key": self.pub, "transactions": len(self.transactions),
                          "vertices": len(self.vertices), "last_sequence": self.last_seq}
            elif typ == "dag":
                result = {"vertices": self.ordered_vertices()}
            else:
                result = {"ok": False, "reason": "unknown message type"}
            writer.write(canon(result) + b"\n")
            await writer.drain()
        except Exception as e:
            try:
                writer.write(canon({"ok": False, "reason": str(e)}) + b"\n")
                await writer.drain()
            except Exception:
                pass
        finally:
            writer.close()
            try: await writer.wait_closed()
            except Exception: pass

    async def accept_transaction(self, tx: dict, gossip: bool):
        if not verify_transaction(tx):
            return False, "invalid signature or transaction encoding"
        txid, body = tx["txid"], tx["body"]
        if txid in self.transactions:
            return True, "duplicate"
        sender, nonce = body["sender"], int(body["nonce"])
        # Prototype rule: only strictly increasing nonces are accepted per sender.
        if nonce <= self.seen_nonces.get(sender, 0):
            return False, "replayed or stale nonce"
        self.seen_nonces[sender] = nonce
        self.transactions[txid] = tx
        self._create_vertex([txid])
        if gossip:
            await self._broadcast({"type": "transaction", "transaction": tx})
        return True, "accepted"

    def _create_vertex(self, txids: list[str]):
        self.last_seq += 1
        body = {"author": self.pub, "author_name": self.name, "sequence": self.last_seq,
                "parents": [self.last_vertex] if self.last_vertex else [],
                "transactions": txids, "created_at": int(time.time())}
        vertex = {"body": body, "signature": b64(self.key.sign(canon(body))), "vertex_id": digest(body)}
        self.vertices[vertex["vertex_id"]] = vertex
        self.last_vertex = vertex["vertex_id"]

    def accept_vertex(self, vertex: dict):
        try:
            body = vertex["body"]
            if vertex["vertex_id"] != digest(body):
                return False, "vertex hash mismatch"
            Ed25519PublicKey.from_public_bytes(unb64(body["author"])).verify(
                unb64(vertex["signature"]), canon(body))
            if vertex["vertex_id"] in self.vertices:
                return True, "duplicate"
            # Parent references must already be known. This prototype doesn't request missing parents.
            if any(p not in self.vertices for p in body["parents"]):
                return False, "missing parent"
            self.vertices[vertex["vertex_id"]] = vertex
            return True, "accepted"
        except Exception:
            return False, "invalid vertex"

    async def _broadcast(self, msg: dict):
        if not self.peers:
            return
        payload = canon(msg) + b"\n"
        async def send(host, port):
            try:
                r, w = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=1.5)
                w.write(payload); await w.drain()
                await asyncio.wait_for(r.readline(), timeout=1.5)
                w.close(); await w.wait_closed()
            except Exception:
                pass
        await asyncio.gather(*(send(h, p) for h, p in self.peers))

    def ordered_vertices(self) -> list[dict]:
        # Stable display order, not a BFT consensus algorithm.
        return sorted(self.vertices.values(), key=lambda v: (
            int(v["body"]["sequence"]), v["body"]["author"], v["vertex_id"]))

async def request(host: str, port: int, msg: dict) -> dict:
    reader, writer = await asyncio.open_connection(host, port)
    writer.write(canon(msg) + b"\n"); await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5)
    writer.close(); await writer.wait_closed()
    return json.loads(line)
