"""Four-node in-process smoke demo. This is a networking demo, not a BFT test."""
import asyncio
from sovereignchain import Node, load_or_create_key, make_transaction, verify_transaction

async def main():
    nodes = [Node(f"validator-{i+1}", load_or_create_key(f".demo_keys/node{i+1}.key")) for i in range(4)]
    ports = [await n.start() for n in nodes]
    for i, node in enumerate(nodes):
        node.peers = [("127.0.0.1", p) for j, p in enumerate(ports) if j != i]
    wallet = load_or_create_key(".demo_keys/wallet.key")
    tx = make_transaction(wallet, "demo-recipient", 10, 1)
    assert verify_transaction(tx)
    ok, reason = await nodes[0].accept_transaction(tx, gossip=True)
    await asyncio.sleep(0.5)
    print("Submission:", ok, reason)
    print("Node transaction counts:", [len(n.transactions) for n in nodes])
    print("Node vertex counts:", [len(n.vertices) for n in nodes])
    for n in nodes:
        print(n.name, "deterministic local DAG order:", [v["vertex_id"][:12] for v in n.ordered_vertices()])
    for n in nodes: await n.close()
    if not all(len(n.transactions) == 1 for n in nodes):
        raise SystemExit("Demo failed: transaction did not reach every node")
    print("PASS: signed transaction propagated to all four local nodes.")
    print("NOTE: this does not demonstrate Byzantine fault tolerance or production consensus.")

if __name__ == "__main__": asyncio.run(main())
