import argparse, asyncio, json
from sovereignchain import Node, load_or_create_key

async def main():
    ap = argparse.ArgumentParser(description="SovereignChain prototype node")
    ap.add_argument("--name", required=True)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--peers", default="", help="comma-separated host:port list")
    args = ap.parse_args()
    peers = []
    for item in filter(None, args.peers.split(",")):
        h, p = item.rsplit(":", 1); peers.append((h, int(p)))
    node = Node(args.name, load_or_create_key(f"{args.data_dir}/node_ed25519.key"), peers)
    port = await node.start(args.host, args.port)
    print(json.dumps({"event":"started","name":args.name,"host":args.host,"port":port,"public_key":node.pub}), flush=True)
    try:
        async with node.server:
            await node.server.serve_forever()
    except asyncio.CancelledError:
        pass
    finally:
        await node.close()

if __name__ == "__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: pass
