# SovereignChain — runnable prototype (Phase 1)

A small, educational Python prototype inspired by the supplied SovereignChain architecture.

## Included
- Independent asyncio TCP nodes with peer-to-peer message forwarding
- Ed25519-signed transactions and signed DAG vertices
- SHA-256 content identifiers
- Duplicate/replay-resistant transaction IDs and per-sender nonces
- Vertex parent references and a deterministic DAG ordering view
- Local status/inspection commands and a 4-node demo
- Basic tests

## Important limitations
This is **not production blockchain software** and does **not** implement Narwhal, Bullshark, Mysticeti, or a proven DAG-BFT protocol. The ordering view is deterministic for a given set of vertices, but nodes may temporarily or permanently have different views under message loss or partitions. There are no quorum certificates, validator membership/bonding, economic rules, durable database, TLS, rate limits, formal TCB boundary, ZK circuits, or AI SOC integration. Do not use real funds or expose nodes to the public internet.

## Requirements
- Python 3.11+
- `cryptography` package

Install:
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Quick demo
Runs four in-process node objects and checks transaction signature verification, transaction propagation, vertex creation, and deterministic ordering:
```bash
python demo.py
```

## Run separate node processes
Open four terminals in this directory. Each node listens on a TCP port and accepts newline-delimited JSON messages.

Terminal 1:
```bash
python node.py --name node1 --port 7101 --data-dir data/node1 --peers 127.0.0.1:7102,127.0.0.1:7103,127.0.0.1:7104
```
Terminal 2:
```bash
python node.py --name node2 --port 7102 --data-dir data/node2 --peers 127.0.0.1:7101,127.0.0.1:7103,127.0.0.1:7104
```
Terminal 3:
```bash
python node.py --name node3 --port 7103 --data-dir data/node3 --peers 127.0.0.1:7101,127.0.0.1:7102,127.0.0.1:7104
```
Terminal 4:
```bash
python node.py --name node4 --port 7104 --data-dir data/node4 --peers 127.0.0.1:7101,127.0.0.1:7102,127.0.0.1:7103
```

Submit a transaction to node1:
```bash
python wallet.py --data-dir data/wallet --to demo-recipient --amount 10 --nonce 1 --node 127.0.0.1:7101
```
The first wallet run creates a wallet keypair and prints its public key. For repeat transactions, use a new nonce each time.

Inspect a node:
```bash
python client.py status --node 127.0.0.1:7101
python client.py dag --node 127.0.0.1:7101
```

## Message protocol
Messages are JSON objects, one per TCP connection/line. Node-to-node message types are `transaction` and `vertex`. Client commands are `submit`, `status`, and `dag`.

## Suggested next milestones
1. Replace the demo ordering rule with a reviewed, specification-driven DAG-BFT protocol and quorum certificates.
2. Define validator membership, fault assumptions, epochs, timeouts, and deterministic execution semantics.
3. Add durable storage, authenticated encrypted transport, quotas, fuzzing, and adversarial network tests.
4. Specify TCB IPC/signing authorization and persist anti-equivocation counters atomically.
5. Integrate ZK proof verification and advisory AI reports only after protocol/security review.
