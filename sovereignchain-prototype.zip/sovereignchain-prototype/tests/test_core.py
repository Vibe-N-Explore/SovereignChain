import unittest
from sovereignchain import load_or_create_key, make_transaction, verify_transaction, digest

class CoreTests(unittest.TestCase):
    def test_signed_transaction(self):
        key = load_or_create_key(".test_keys/wallet.key")
        tx = make_transaction(key, "recipient", 3, 1)
        self.assertTrue(verify_transaction(tx))
        tx["body"]["amount"] = 99
        self.assertFalse(verify_transaction(tx))

    def test_digest_is_stable(self):
        self.assertEqual(digest({"b":2,"a":1}), digest({"a":1,"b":2}))

if __name__ == "__main__": unittest.main()
