import argparse, asyncio, json
from sovereignchain import request

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["status", "dag"])
    ap.add_argument("--node", required=True, help="host:port")
    args = ap.parse_args()
    host, port = args.node.rsplit(":", 1)
    result = await request(host, int(port), {"type": args.command})
    print(json.dumps(result, indent=2))
if __name__ == "__main__": asyncio.run(main())
