import argparse, asyncio, json
from pathlib import Path
from sovereignchain import load_or_create_key, make_transaction, public_bytes, b64, request

async def main():
    ap = argparse.ArgumentParser(description="Create and submit a signed demo transaction")
    ap.add_argument("--data-dir", default="data/wallet")
    ap.add_argument("--to", required=True)
    ap.add_argument("--amount", type=int, required=True)
    ap.add_argument("--nonce", type=int, required=True)
    ap.add_argument("--node", required=True, help="host:port")
    args = ap.parse_args()
    key = load_or_create_key(f"{args.data_dir}/wallet_ed25519.key")
    tx = make_transaction(key, args.to, args.amount, args.nonce)
    print("Wallet public key:", b64(public_bytes(key)))
    host, port = args.node.rsplit(":", 1)
    result = await request(host, int(port), {"type":"submit", "transaction":tx})
    print(json.dumps({"transaction": tx, "result": result}, indent=2))
if __name__ == "__main__": asyncio.run(main())
